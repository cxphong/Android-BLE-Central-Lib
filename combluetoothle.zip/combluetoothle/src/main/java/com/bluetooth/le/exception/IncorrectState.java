package com.bluetooth.le.exception;

/**
 * Created by caoxuanphong on 4/5/17.
 */

public class IncorrectState extends Exception {

    public IncorrectState(String detailMessage) {
        super(detailMessage);
    }
    
}
