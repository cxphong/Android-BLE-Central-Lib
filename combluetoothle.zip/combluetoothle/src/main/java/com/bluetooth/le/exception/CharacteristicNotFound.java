package com.bluetooth.le.exception;

/**
 * Created by caoxuanphong on 5/12/17.
 */

public class CharacteristicNotFound extends Exception {
    public CharacteristicNotFound(String message) {
        super(message);
    }
}
