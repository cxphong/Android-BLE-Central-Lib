package com.bluetooth.le.exception;

/**
 * Created by caoxuanphong on 4/5/17.
 */

public class NotSupportBleException extends Exception {

    public NotSupportBleException(String detailMessage) {
        super(detailMessage);
    }

}
