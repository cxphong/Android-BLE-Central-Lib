package com.bluetooth.le.exception;

/**
 * Created by caoxuanphong on 4/5/17.
 */

public class NotFromActivity extends Exception {

    public NotFromActivity(String detailMessage) {
        super(detailMessage);
    }
    
}
