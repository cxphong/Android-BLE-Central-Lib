package com.bluetooth.le.exception;

/**
 * Created by caoxuanphong on 4/5/17.
 */

public class NotAcceptPermisson extends Exception {

    public NotAcceptPermisson(String detailMessage) {
        super(detailMessage);
    }
    
}
